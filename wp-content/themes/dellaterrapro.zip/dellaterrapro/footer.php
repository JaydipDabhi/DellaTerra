<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package dellaterrapro
 */

?>

	<footer id="colophon" class="site-footer footer-section">
		<div class="container">
			<div class="footer-site">
				<a href="#" class="foote-logo"><picture><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/logo.webp" alt="logo" height="100" width="112"/></picture></a>
				<h2 class="sub-heading">Receive 1x a month content to guide you in real estate and hospitality investing and management.</h2>
				<form>
					<div class="subscribe-form">
					  <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
					  <button type="submit" class="subscribe-btn">Subscribe</button>
					  <!-- <span class="error-text">We'll never share your email with anyone else.</span> -->
					</div>
				</form>
				<ul class="footer-link">
					<li><a href="" title="Home">Home</a></li>
					<li><a href="" title="About Us">About Us</a></li>
					<li><a href="" title="Project Gallery">Project Gallery</a></li>
					<li><a href="" title="Blog">Blog</a></li>
					<li><a href="" title="Reviews">Reviews</a></li>
					<li><a href="" title="Contact Us">Contact Us</a></li>
				</ul>
				<div class="footer-bottom">
					<ul class="bottom-link">
						<li>@2024 Della Terra. All Right Reserved.</li>
						<li class="links"><a href="#" title="Privacy Policy">Privacy Policy</a> <a href="#" title="Featured Links">Featured Links</a></li>
					</ul>
					<div class="share-link">
						<a href="#" title="Facebook">
							<picture><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/facebook-icon.svg" alt="facebook" height="40" width="40"/></picture>
						</a>
						 <a href="#" title="Instagram">
							<picture><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/instagram-icon.svg" alt="instagram" height="40" width="40"/></picture>
						</a>
					</div>
				</div>
			</div>
		</div>
	</footer><!-- #colophon -->
</div><!-- #page -->
<?php wp_footer(); ?>

<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<!-- lazysizes JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.3.2/lazysizes.min.js" integrity="sha512-q583ppKrCRc7N5O0n2nzUiJ+suUv7Et1JGels4bXOaMFQcamPk9HjdUknZuuFjBNs7tsMuadge5k9RzdmO+1GQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="<?php echo get_template_directory_uri().'/js/jquery.fancybox.min.js'; ?>"></script>
<!-- <script type="text/javascript" src="https://dellaterrapro.com/wp-content/themes/della-terra/assets/js/fancybox.umd.js?ver=6.5.3" id="blankslate-main-fancybox-js-js"></script> -->
<script src="<?php echo get_template_directory_uri().'/js/custom.js'; ?>"></script>
</body>
</html>
