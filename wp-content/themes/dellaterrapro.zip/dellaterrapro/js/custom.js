

  $( document ).ready(function() {

    // Header sticky
      $(window).scroll(function () {
        if ($(this).scrollTop() >= 1) {
          $(".header-section").addClass("sticky");
        } else {
          $(".header-section").removeClass("sticky");
        }
      });

      // customer Reviews slider

      var swiper = new Swiper(".reviewsSwiper", {
        loop: true,
        autoplay: {
          delay: 5000,
          disableOnInteraction: false,
        },
        slidesPerView: 2.5,
        spaceBetween: 30
      });

      // Project Gallery slider Fancybox Config

      $('[data-fancybox="gallery"]').fancybox({
        buttons: [
          "slideShow",
          "thumbs",
          "zoom",
          "fullScreen",
          "close"
        ],
        loop: false,
        protect: true,
        thumbs: {
          autoStart: true,
          axis: 'x'
        }
      });

});