<?php
 /*
    Template Name: Project Gallery
*/ 
get_header();
?>
   <!-- All paeg Banner Section -->
   <section class="all-banner-section">
     <div class="container">
         <div class="main-text">
            <h1 class="page-title">Project Gallery</h1>
         </div>
      </div>
    </section>

    <!-- Some of Our Places -->

    <section class="our-project-section">
         <div class="container">
            <ul class="project-name-list">
               <li><a href="#" title="Long Term Rentals" class="pro-btn active">Long Term Rentals</a></li>
               <li><a href="#" title="Property Management" class="pro-btn">Property Management</a></li>
               <li><a href="#" title="Real Estate and Hospitality" class="pro-btn">Real Estate and Hospitality</a></li>
               <li><a href="#" title="Short and Medium Term Rentals" class="pro-btn">Short and Medium Term Rentals</a></li>
               <li><a href="#" title="Past Projects" class="pro-btn">Past Projects</a></li>
            </ul>
            
            <div class="project-list-box">
               <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/image-slider.png" alt="Some of Our Places" class="project-box" data-fancybox="gallery" data-caption="Urban 4 bd home Blackstone District Omaha, NE">
                  <picture><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/image-slider.png" alt="howard-st-apartment" height="330" width="400"></picture>
                  <span>Urban 4 bd home Blackstone District Omaha, NE</span>
               </a>
               <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/mount-cook.webp" alt="Some of Our Places" class="project-box" data-fancybox="gallery" data-caption="urban entryway Mount Cook Wellington, New Zealand">
                  <picture><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/mount-cook.webp" alt="mount-cook" height="330" width="400"></picture>
                  <span>urban entryway Mount Cook Wellington, New Zealand</span>
               </a>
               <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/howard-st-apartment2.webp" alt="Some of Our Places" class="project-box" data-fancybox="gallery" data-caption="Garage apartment unit kitchen Omaha, NE">
                  <picture><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/howard-st-apartment2.webp" alt="howard-st-apartment" height="330" width="400"></picture>
                  <span>Garage apartment unit kitchen Omaha, NE</span>
               </a>
               <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/howard-st-apartment.webp" alt="Some of Our Places" class="project-box" data-fancybox="gallery">
                  <picture><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/howard-st-apartment.webp" alt="howard-st-apartment" height="330" width="400"></picture>
                  <span>Urban 4 bd home Blackstone District Omaha, NE</span>
               </a>
               <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/mount-cook.webp" alt="Some of Our Places" class="project-box" data-fancybox="gallery">
                  <picture><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/mount-cook.webp" alt="mount-cook" height="330" width="400"></picture>
                  <span>urban entryway Mount Cook Wellington, New Zealand</span>
               </a>
               <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/howard-st-apartment2.webp" alt="Some of Our Places" class="project-box" data-fancybox="gallery">
                  <picture><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/howard-st-apartment2.webp" alt="howard-st-apartment" height="330" width="400"></picture>
                  <span>Garage apartment unit kitchen Omaha, NE</span>
               </a>
               <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/howard-st-apartment.webp" alt="Some of Our Places" class="project-box" data-fancybox="gallery">
                  <picture><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/howard-st-apartment.webp" alt="howard-st-apartment" height="330" width="400"></picture>
                  <span>Urban 4 bd home Blackstone District Omaha, NE</span>
               </a>
               <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/mount-cook.webp" alt="Some of Our Places" class="project-box" data-fancybox="gallery">
                  <picture><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/mount-cook.webp" alt="mount-cook" height="330" width="400"></picture>
                  <span>urban entryway Mount Cook Wellington, New Zealand</span>
               </a>
               <a href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/howard-st-apartment2.webp" alt="Some of Our Places" class="project-box" data-fancybox="gallery">
                  <picture><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/howard-st-apartment2.webp" alt="howard-st-apartment" height="330" width="400"></picture>
                  <span>Garage apartment unit kitchen Omaha, NE</span>
               </a>
            </div>
            <div class="terra-btn">
               <a href="#" class="della-btn" title="Load More">
                  <span class="btn-text">Load More</span>         
                  <picture class="icon-img"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/round-arrow-black.svg" alt="round-arrow" /></picture> 
               </a>
            </div>
         </div>
   </section>

<?php 
get_footer();
?>