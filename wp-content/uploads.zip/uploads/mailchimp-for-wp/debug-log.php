<?php exit; ?>
[2024-06-06 11:23:54] WARNING: Contact Form 7 > trup************@cm****.com is already subscribed to the selected list(s)
[2024-06-06 11:27:06] WARNING: Contact Form 7 > trup************@cm****.com is already subscribed to the selected list(s)
[2024-06-07 05:04:04] WARNING: Contact Form 7 > trup************@cm****.com is already subscribed to the selected list(s)
[2024-06-07 05:27:49] WARNING: Contact Form 7 > trup************@cm****.com is already subscribed to the selected list(s)
[2024-06-07 05:40:38] WARNING: Contact Form 7 > trup************@cm****.com is already subscribed to the selected list(s)
[2024-06-07 05:51:00] WARNING: Contact Form 7 > Unable to find EMAIL field.
[2024-06-07 05:54:38] WARNING: Contact Form 7 > Unable to find EMAIL field.
[2024-06-07 05:55:53] WARNING: Contact Form 7 > Unable to find EMAIL field.
[2024-06-07 05:59:34] WARNING: Contact Form 7 > Unable to find EMAIL field.
[2024-06-07 06:05:02] WARNING: Contact Form 7 > Unable to find EMAIL field.
[2024-06-07 06:07:01] WARNING: Contact Form 7 > Unable to find EMAIL field.
[2024-06-07 06:36:09] WARNING: Contact Form 7 > Unable to find EMAIL field.
[2024-06-07 06:53:41] WARNING: Contact Form 7 > Unable to find EMAIL field.
[2024-06-07 06:54:44] WARNING: Contact Form 7 > Unable to find EMAIL field.
[2024-06-07 06:59:41] WARNING: Contact Form 7 > Unable to find EMAIL field.
[2024-06-10 09:08:43] ERROR: Contact Form 7 > Mailchimp API Error: Bad Request. Invalid Resource. ates****@yo*****.com looks fake or invalid, please enter a real email address.

Request: 
POST https://us14.api.mailchimp.com/3.0/lists/edbbc414ed/members

{"status":"subscribed","email_address":"ates****@yo*****.com","interests":{},"merge_fields":{},"email_type":"html","ip_signup":"192.168.100.1","tags":[]}

Response: 
400 Bad Request
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"Invalid Resource","status":400,"detail":"ates****@yo*****.com looks fake or invalid, please enter a real email address.","instance":"01fd42d8-83a2-fea4-b7b0-c9e3764b0656"}
[2024-06-10 11:50:02] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-10 11:50:04] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-10 11:50:37] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-10 11:50:38] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-10 11:50:39] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-10 11:50:39] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-10 11:50:39] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-10 11:50:39] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-10 11:51:38] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-10 11:51:38] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-10 11:51:38] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-10 11:51:38] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-10 11:51:38] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-11 06:21:54] ERROR: Contact Form 7 > Mailchimp API Error: cURL error 28: Resolving timed out after 10000 milliseconds.

Request: 
POST https://us14.api.mailchimp.com/3.0/lists/edbbc414ed/members

{"status":"subscribed","email_address":"abc@ab*.com","interests":{},"merge_fields":{},"email_type":"html","ip_signup":"192.168.100.1","tags":[]}
[2024-06-11 06:22:03] ERROR: Contact Form 7 > Mailchimp API Error: Bad Request. Invalid Resource. abc@ab*.com looks fake or invalid, please enter a real email address.

Request: 
POST https://us14.api.mailchimp.com/3.0/lists/edbbc414ed/members

{"status":"subscribed","email_address":"abc@ab*.com","interests":{},"merge_fields":{},"email_type":"html","ip_signup":"192.168.100.1","tags":[]}

Response: 
400 Bad Request
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"Invalid Resource","status":400,"detail":"abc@ab*.com looks fake or invalid, please enter a real email address.","instance":"fe7c3cc7-260e-8bf4-b0e5-bc2cdd9ecfd0"}
[2024-06-11 07:18:56] WARNING: Contact Form 7 > trup************@cm****.com is already subscribed to the selected list(s)
[2024-06-11 07:18:56] WARNING: Contact Form 7 > trup************@cm****.com is already subscribed to the selected list(s)
[2024-06-11 07:18:57] WARNING: Contact Form 7 > trup************@cm****.com is already subscribed to the selected list(s)
[2024-06-11 07:18:57] WARNING: Contact Form 7 > trup************@cm****.com is already subscribed to the selected list(s)
[2024-06-11 07:22:01] WARNING: Contact Form 7 > trup************@cm****.com is already subscribed to the selected list(s)
[2024-06-12 04:49:24] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-19 04:58:35] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-19 05:00:16] WARNING: Contact Form 7 > trup************@cm****.com is already subscribed to the selected list(s)
[2024-06-27 08:59:06] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-06-27 09:00:45] WARNING: Contact Form 7 > mila********@gm***.com is already subscribed to the selected list(s)
[2024-07-03 06:57:24] ERROR: Contact Form 7 > Mailchimp API Error: Bad Request. Invalid Resource. test@gm***.com looks fake or invalid, please enter a real email address.

Request: 
POST https://us14.api.mailchimp.com/3.0/lists/edbbc414ed/members

{"status":"subscribed","email_address":"test@gm***.com","interests":{},"merge_fields":{},"email_type":"html","ip_signup":"192.168.100.1","tags":[]}

Response: 
400 Bad Request
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"Invalid Resource","status":400,"detail":"test@gm***.com looks fake or invalid, please enter a real email address.","instance":"adea4bdd-6c77-d61b-835a-4d173b1a3fb6"}
[2024-09-13 09:13:07] ERROR: Contact Form 7 > Mailchimp API Error: cURL error 28: Resolving timed out after 10000 milliseconds.

Request: 
GET https://us14.api.mailchimp.com/3.0/lists/edbbc414ed/members/c6f64d1539a5d397e38242706b97d620
[2024-09-16 13:08:57] ERROR: Contact Form 7 > Mailchimp API Error: Bad Request. Invalid Resource. voqy**@ma********.com looks fake or invalid, please enter a real email address.

Request: 
POST https://us14.api.mailchimp.com/3.0/lists/edbbc414ed/members

{"status":"subscribed","email_address":"voqy**@ma********.com","interests":{},"merge_fields":{},"email_type":"html","ip_signup":"192.168.100.1","tags":[]}

Response: 
400 Bad Request
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"Invalid Resource","status":400,"detail":"voqy**@ma********.com looks fake or invalid, please enter a real email address.","instance":"1565ce08-69e8-ec74-5969-11c37d21eb4e"}
